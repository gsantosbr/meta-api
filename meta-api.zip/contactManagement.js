//inicial configuration
const express = require('express'),
    path = require('path'),
    bodyParser = require('body-parser'),
    app = express();

const consign = require('consign');

require('dotenv').config();

//parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true })); //support x-www-form-urlencoded

//parse application/json
app.use(bodyParser.json());

app.use('/meta-api/public', express.static('public'));
app.use(express.static('fonts'));

//load resources
consign()
    .include('infra')
    .then('controllers')
    .then('routes')
    .into(app);

//apply router
app.use('/api', app.infra.router);

//start Server
const server = app.listen("8080", function () {

    console.log("Listening to port %s", server.address().port);

});
