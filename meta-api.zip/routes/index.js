/** Rota para Index. **/
module.exports = function (app) {

    app.get('/', function (req, res) {
        var contentType = {
            'content-type': 'text/html; charset=utf-8'
        };

        // enviar resposta.
        res.status(200).set(contentType).sendFile('index.html', {
            root: '../meta-api/views/'
        });
    });


    var getContacts = app.infra.router.route('/getContacts');
    getContacts.get(app.controllers.contact.getContacts);

    var addContact = app.infra.router.route('/addContact');
    addContact.post(app.controllers.contact.addContact);

    var updateContacts = app.infra.router.route('/updateContacts');
    updateContacts.put(app.controllers.contact.updateContacts);

    var deleteContacts = app.infra.router.route('/deleteContacts');
    deleteContacts.delete(app.controllers.contact.deleteContacts);
};