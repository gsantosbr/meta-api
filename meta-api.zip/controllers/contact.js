/** Controller CONTACT. **/
'use strict';
module.exports = function (app) {

    let controller = {};

    controller.getContacts = function (req, res, next) {

        const contacts = [
            {
                "_id": 1,
                "Nome": "John Smith",
                "Canal": "Email",
                "Valor": "john@teste.com",
                "Observacao": "Dados de John"
            },
            {
                "_id": 2,
                "Nome": "Jane Smith",
                "Canal": "Telefone",
                "Valor": "+55 21 9999-9999",
                "Observacao": "Dados de Jane"
            },
        ];

        return res.status(200).json(contacts);

    };

    controller.addContact = function (req, res, next) {

        if(req.body.nome != "") {
            console.log("objContact:", req.body);
            return res.status(201).json("Dados inseridos com sucesso");
        } else {
            return res.status(400).json("Ocorreu um erro durante o processo");
        }

    };

    controller.updateContacts = function (req, res, next) {

        return res.status(200).json("success");

    };

    controller.deleteContacts = function (req, res, next) {

        return res.status(200).json("success");

    };

    return controller;
};