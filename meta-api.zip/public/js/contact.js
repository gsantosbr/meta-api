$(document).ready(function () {

    getContacts();

    $("#btn-add").click(function () {

        var nome = $("#nome").val();
        var canal = $("#tipocanal option:selected").text();
        var valor = $("#valor").val();
        var obs = $("#obs").val();

        addContact(nome, canal, valor, obs);
    });
});

function getContacts() {

    $.get("/api/getContacts")
        .done(function (res) {

            $.each(res, function (i, contact) {

                $("<tr>").append(
                    $("<td>").text(contact._id),
                    $("<td>").text(contact.Nome),
                    $("<td>").text(contact.Canal),
                    $("<td>").text(contact.Valor),
                    $("<td>").text(contact.Observacao),
                    $("<td>").html('<a href="#">EDIT</a> | <a href="#">DELETE</a>'),
                ).appendTo(".table-manager tbody");
            });

        })

        .fail(function (res) {
            alert("Ocorreu um erro durante o processo.");
        });
}

function addContact(nome, canal, valor, obs) {

    $("#btn-add").attr('disabled', true);

    $.post("api/addContact", {"nome": nome, "canal": canal, "valor": valor, "obs": obs })
        .done(function (res) {

            console.log(res);
            alert(res);

            $("#btn-add").attr('disabled', false);

        })

        .fail(function (data) {
            alert("Ocorreu um erro durante o processo.");
            $("#btn-add").attr('disabled', false);
        });
}