var express = require('express');

module.exports = function (app) {

    var roteador = express.Router();

    roteador.use(function (req, res, next) {

        next();
    });

    return roteador;
};
