const restful = require('node-restful')
const mongoose = restful.mongoose

const contactSchema = new mongoose.Schema({
    nome: { type: String, required: true },
    canal: { type: String, required: true },
    valor: { type: String, required: true },
    observacao: { type: String, required: true },
    createdAt: { type: Date, default: Date.now }
})

module.exports = restful.model('Contact', contactSchema)