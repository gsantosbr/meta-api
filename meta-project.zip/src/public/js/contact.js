$(document).ready(function () {

    getContacts();

    $("#btn-add").click(function () {

        var id = $("#contact").val();
        var nome = $("#nome").val();
        var canal = $("#tipocanal option:selected").val();
        var valor = $("#valor").val();
        var obs = $("#obs").val();

        addContact(id, nome, canal, valor, obs);
    });
});

function getContacts() {

    $(".table-manager tbody tr").remove();

    $.get("/api/contacts")
        .done(function (res) {

            console.log('res', res);

            $.each(res, function (i, contact) {

                $("<tr>").append(
                    $("<td>").text(contact._id),
                    $("<td>").text(contact.nome),
                    $("<td>").text(contact.canal),
                    $("<td>").text(contact.valor),
                    $("<td>").text(contact.observacao),
                    $("<td>").html(`<a href="#" onclick="loadContact('${contact._id}')">EDIT</a> | <a href="#" onclick="removeContact('${contact._id}')">DELETE</a>`),
                ).appendTo(".table-manager tbody");
            });

        })

        .fail(function (res) {
            alert("Ocorreu um erro durante o processo.");
        });
}

function addContact(id, nome, canal, valor, obs) {

    $("#btn-add").attr('disabled', true);

    if (id) {

        $.ajax({
            url: `api/contacts/${id}`,
            type: 'put',
            data: { "nome": nome, "canal": canal, "valor": valor, "observacao": obs },
            dataType: "json",
            success: function (response) {
                alert("Registro alterado com sucesso!");
                $("#frm-manager")[0].reset();
                $("#btn-add").attr('disabled', false);
                $("#contact").val("");
                getContacts();
            },
            error: function (error) { 
                alert("Ocorreu um erro durante o processo!");
                return false;
            }
        });

    } else {

        $.post("api/contacts", { "nome": nome, "canal": canal, "valor": valor, "observacao": obs })
            .done(function (res) {

                console.log(res);
                alert("Adicionado com sucesso");
                $("#btn-add").attr('disabled', false);
                $("#frm-manager")[0].reset();
                getContacts();

            })

            .fail(function (data) {
                alert("Ocorreu um erro durante o processo.");
                $("#btn-add").attr('disabled', false);
            });

    }
}

function removeContact(id) {

    $.ajax({
        url: `api/contacts/${id}`,
        type: 'delete',
        dataType: "json",
        success: function () {
            alert("Registro removido com sucesso!");
            getContacts();
        },
        error: function (error) {
            alert("Ocorreu um erro durante o processo!");
            return false;
        }

    });
}

function loadContact(id) {

    $.ajax({
        url: `api/contacts/${id}`,
        type: 'get',
        dataType: "json",
        success: function (response) {

            $("#contact").val(response._id);
            $("#nome").val(response.nome);
            $("#tipocanal").val(response.canal);
            $("#valor").val(response.valor);
            $("#obs").val(response.observacao);
    
        },
        error: function (error) {
            alert("Ocorreu um erro durante o processo!");
            return false;
        }

    });
}