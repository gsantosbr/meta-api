const express = require('express')

module.exports = function(server) {

    // INDEX Routes
    server.get('/', function (req, res) {
        var contentType = {
            'content-type': 'text/html; charset=utf-8'
        };

        // enviar resposta.
        res.status(200).set(contentType).sendFile('index.html', {
            root: '../meta-project/src/views/'
        });
    });


    // API Routes
    const router = express.Router()
    server.use('/api', router)

    // CONTACT Routes
    const contactService = require('../api/contact/contactService')
    contactService.register(router, '/contacts')
}