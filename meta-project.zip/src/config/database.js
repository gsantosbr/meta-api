const mongoose = require('mongoose')
mongoose.Promise = global.Promise
module.exports = mongoose.connect('mongodb://admin:jsTr6hDGXBQgX8v@ds363996.mlab.com:63996/contact')