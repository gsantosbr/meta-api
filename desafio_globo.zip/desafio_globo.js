function questao1() {

    let intArr = [2, 5, 8, 3]
    const target = 10

    for (var i = 0; i < intArr.length; i++) {
        for (var j = 0; j < intArr.length; j++) {
            
            if( i != j ) {
                if( intArr[i] + intArr[j] == target )
                {
                    console.log( 'index:', i + ' - ' + 'val:', intArr[i] );
                    console.log( 'index:', j + ' - ' + 'val:', intArr[j] );
                    console.log( 'Resultado:', intArr[i] + intArr[j] )
                    intArr.splice(i, 1);
                    intArr.splice(j-1, 1);
                    console.log(intArr)
                }
            }
        }
    }
}

function questao3() {

    let stocksArr = [7,2,5,3,6,4]

    let minIndex = stocksArr.indexOf(Math.min(...stocksArr));
    let minValue = Math.min.apply(Math, stocksArr);

    stocksArr.splice(0, minIndex+1)

    if( stocksArr.length > 0 ) {
        let maxValue = Math.max.apply(Math, stocksArr);
        console.log("Comprou", minValue)
        console.log("Vendeu", maxValue)
        console.log("Lucro", maxValue - minValue)
    } else {
        console.log("Transação não realizada")
    }
}
